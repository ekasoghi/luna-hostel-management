# 🏨 Luna's Hostel Management - VPS Deployment

Skrip otomatis untuk install, update, backup, restore & auto-deploy aplikasi **Luna’s Hostel Management** di VPS berbasis Ubuntu.

## 📦 Fitur
- Install Laravel lengkap (Apache, MySQL, PHP, Node)
- Setup database, queue, scheduler, SSL
- Backup harian + unggah ke Google Drive
- Restore backup otomatis
- Notifikasi WhatsApp saat backup sukses
- Auto-deploy dari GitHub Actions

## ⚙️ Perintah Dasar

| Perintah               | Fungsi                                   |
|------------------------|-------------------------------------------|
| `./setup.sh`           | Instalasi penuh                           |
| `./setup.sh update`    | Partial update (GitHub Actions safe)      |
| `./setup.sh restore`   | Restore database dari Google Drive backup |

## 🛠️ Konfigurasi Manual

1. Buat file rahasia:
```bash
nano /var/www/lunas_hostel_mgmt/.env.secret
```
Isi:
```
TWILIO_SID=...
TWILIO_AUTH_TOKEN=...
TWILIO_FROM=whatsapp:+14155238886
ADMIN_WHATSAPP=whatsapp:+628xxxxxxx
```

2. Jalankan:
```bash
chmod 600 .env.secret
rclone config  # Untuk Google Drive
```

3. GitHub Secrets (untuk auto-deploy):
- `VPS_HOST`
- `VPS_USER`
- `VPS_SSH_KEY`

## 🔐 Lisensi
MIT License (bebas digunakan & dimodifikasi)
